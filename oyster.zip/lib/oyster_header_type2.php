<!--<!DOCTYPE html>-->
<!--<html><head>-->
<!--    <title>Welcome to oyster</title>-->
	 
<!--    <meta name="keywords" content="">-->
<!--	<meta name="description" content="">-->
<!--    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">-->
<!--	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">-->
	
<!--	<link rel="icon" type="image/png" href="imgs/favicon-oyster.png">-->
	
    <!--main file-->
<!--	<link href="css/oyster-hotel.css" rel="stylesheet" type="text/css">-->
    
    <!--Medical Guide Icons-->
<!--	<link href="fonts/oyster-icons.css" rel="stylesheet" type="text/css">-->
	
	<!-- Default Color-->
<!--	<link href="css/default-color.css" rel="stylesheet" id="color"  type="text/css">-->
    
    <!--bootstrap-->
<!--	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">-->
    
    <!--Dropmenu-->
<!--	<link href="css/dropmenu.css" rel="stylesheet" type="text/css">-->
    
	<!--Sticky Header-->
<!--	<link href="css/sticky-header.css" rel="stylesheet" type="text/css">-->
	
	<!--Sticky Countdown-->
<!--	<link href="css/countdown.css" rel="stylesheet" type="text/css">-->
	
	<!--revolution-->
<!--	<link href="css/settings.css" rel="stylesheet" type="text/css">    -->
<!--    <link href="css/extralayers.css" rel="stylesheet" type="text/css">    -->
   
    <!--Owl Carousel-->
<!--	<link href="css/owl.carousel.css" rel="stylesheet" type="text/css">    -->
	
    <!-- Mobile Menu -->
<!--	<link rel="stylesheet" type="text/css" href="css/jquery.mmenu.all.css" />-->
	
	
	<!--PreLoader-->
<!--	<link href="css/loader.css" rel="stylesheet" type="text/css">    -->
   
    
<!--</head>-->
<!--  <body>-->
    
	
	
<!--  <div id="wrap">-->
   
   <!--Start PreLoader-->
<!--   <div id="preloader">-->
<!--		<div id="status">&nbsp;</div>-->
<!--		<div class="loader">-->
<!--			<h1>Loading...</h1>-->
<!--			<span></span>-->
<!--			<span></span>-->
<!--			<span></span>-->
<!--		</div>-->
<!--	</div>-->
	<!--End PreLoader--> 

  
   <!--Start Header-->
	
<!--       <header class="header-two">-->
<!--		   <div class="container">-->
<!--	   		<a href="index.html"><img class="logo2" src="imgs/logo2.png" alt=""></a>-->
<!--			<a href="index.html"><img class="logo-dark" src="imgs/logo-dark.png" alt=""></a>-->
			
<!--			<div class="cont-right">-->
			
<!--            <nav class="menu-5 nav">-->
<!--            	<ul class="wtf-menu">-->
<!--                	<li><a href="#.">Home</a>-->
					
<!--					<ul class="submenu">-->
<!--                        <li> <a href="index.html">Home 1</a> </li>-->
<!--                        <li> <a href="index2.html">Home 2</a> </li>-->
<!--					</ul>-->
					
<!--					</li>-->
					
<!--					<li><a href="about-us.html">about us</a></li>-->
<!--					<li><a href="accommodation.html">Accommodation</a></li>-->
					
<!--					<li><a href="#.">Blog</a>-->
<!--					<ul class="submenu">-->
<!--                        <li><a href="blog-hotel.html">blog 1</a></li>-->
<!--						<li><a href="blog2-hotel.html">blog 2</a></li>-->
<!--					</ul>-->
					
<!--					</li>-->

					
<!--					<li class="select-item"><a href="#.">contact us</a>-->
					
<!--					<ul class="submenu">-->
<!--                        <li><a href="contact-us-hotel.html" class="select">contact-us 1</a></li>-->
<!--						<li><a href="contact-us2-hotel.html">contact-us 2</a></li>-->
<!--					</ul>-->
					
<!--					</li>-->
<!--                </ul>	-->
<!--            </nav>-->
            
<!--			<ul class="social-icons">-->
<!--				<li><a href="#."><i class="icon-facebook-1"></i></a></li>-->
<!--				<li><a href="#."><i class="icon-twitter-1"></i></a></li>-->
<!--				<li><a href="#."><i class="icon-google"></i></a></li>-->
<!--			</ul>-->
			
			
<!--			<ul class="get-touch">-->
<!--				<li class="contact-no"><a><i class="icon-telephone-receiver"></i> <span>+123 55 33 444</span></a></li>-->
<!--			</ul>-->
			
<!--			</div>-->
<!--		</div>-->
	
<!--       </header>-->

    
   <!--End Header-->
	
	
	
	
	
	<!-- Mobile Menu Start -->
<!--	<div class="container">-->
<!--    <div id="page">-->
<!--			<header class="header">-->
<!--				<a href="#menu"></a>-->
				
<!--			</header>-->
			
<!--			<nav id="menu">-->
<!--				<ul>-->
<!--					<li><a href="#.">Home</a>-->
<!--                    	<ul>-->
<!--							<li> <a href="index.html">Home Page 1</a> </li>-->
<!--							<li> <a href="index2.html">Home Page 2</a> </li>-->
<!--						</ul>-->
<!--                    </li>-->
					
<!--					<li><a href="about-us.html">About Us</a></li>-->
<!--					<li><a href="accommodation.html">Accommodation</a></li>-->
					
<!--                    <li><a href="#.">Blog</a>-->
<!--                    	<ul>-->
<!--                        	<li> <a href="blog-hotel.html">Blog 1</a> </li>-->
<!--							<li> <a href="blog2-hotel.html">Blog 2</a> </li>-->
<!--                        </ul>-->
<!--                    </li>-->
					
<!--					<li class="select"><a href="#.">Contact Us</a>-->
<!--                    	<ul>-->
<!--                        	<li class="select"><a href="contact-us-hotel.html">contact-us 1</a></li>-->
<!--							<li><a href="contact-us2-hotel.html">contact-us 2</a></li>-->
<!--                        </ul>-->
<!--                    </li>-->

<!--					</ul>-->
                
                
<!--			</nav>-->
<!--		</div>-->
<!--		</div>-->
    <!-- Mobile Menu End -->
    
    
<!--- USING the Main Header for Osyters; Will update Later ---->

<!DOCTYPE html>
<html><head>
    <title>Oyster Shell Hotel & Apartments</title>
	 
    <meta name="keywords" content="">
	<meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	
	<link rel="icon" type="image/png" href="imgs/favicon-oyster.png">
	
    <!--main file-->
	<link href="css/oyster-hotel.css" rel="stylesheet" type="text/css">
    
    <!--Medical Guide Icons-->
	<link href="fonts/oyster-icons.css" rel="stylesheet" type="text/css">
	
	<!-- Default Color-->
	<link href="css/default-color.css" rel="stylesheet" id="color"  type="text/css">
    
    <!--bootstrap-->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
    
    <!--Dropmenu-->
	<link href="css/dropmenu.css" rel="stylesheet" type="text/css">
    
	<!--Sticky Header-->
	<link href="css/sticky-header.css" rel="stylesheet" type="text/css">
	
	<!--Sticky Countdown-->
	<link href="css/countdown.css" rel="stylesheet" type="text/css">
	
	<!--revolution-->
	<link href="css/settings.css" rel="stylesheet" type="text/css">    
    <link href="css/extralayers.css" rel="stylesheet" type="text/css">    
   
    <!--Owl Carousel-->
	<link href="css/owl.carousel.css" rel="stylesheet" type="text/css">    
	
	<!--Date Picker-->
	<link href="css/date-pick.css" rel="stylesheet" type="text/css">    
	
	<!--Form Dropdown-->
	<link href="css/form-dropdown.css" rel="stylesheet" type="text/css">    
	
    <!-- Mobile Menu -->
	<link rel="stylesheet" type="text/css" href="css/jquery.mmenu.all.css" />
	
	<!--PreLoader-->
	<link href="css/loader.css" rel="stylesheet" type="text/css">    
   
<style>
    .header .logo {
    width: 255px;
    float: left;
    /* margin: 14px 0px 0 0; */
    padding: 0 15px; 
    height: 55px;
    padding-bottom: 10px;
}
.booking-steps .price-detail .room-price span.current {
    font-size:24px;
}

@media (max-width: 767px) {
    .logo {
        display: block;
    }
}


  /* Custom Styles for FAQ Page */
        .faqpgelem-container {
            padding: 30px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .faqpgelem-title {
            margin-top: 0px;
            text-align: center;
            font-size: 2em;
            color: #333;
        }

        .faqpgelem-panel {
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .faqpgelem-panel-heading {
            background-color: #f5f5f5;
            border-bottom: 1px solid #ddd;
            padding: 10px 15px;
        }

        .faqpgelem-panel-title a {
            color: #333;
            text-decoration: none;
        }

        .faqpgelem-panel-title a:hover {
            text-decoration: underline;
        }

        .faqpgelem-panel-body {
            padding: 15px;
            background-color: #fff;
        }

</style>
    
</head>
  <body>
    
	
	
  <div id="wrap">
   
   <!--Start PreLoader-->
   <div id="preloader">
		<div id="status">&nbsp;</div>
		<div class="loader">
			<h1>Oyster...</h1>
			<span></span>
			<span></span>
			<span></span>
		</div>
	</div>
	<!--End PreLoader--> 

  
   <!--Start Header-->
	
       <header class="header">
	   		<a href="index.html"><img class="logo" src="https://res.cloudinary.com/dsz9ofw6a/image/upload/v1723697809/Group_151_ccft0y.png" alt=""></a>
			
            <nav class="menu-5 nav">
            	<ul class="wtf-menu">
                	<li><a class="select-item" href="./">Home</a>
					
			
					
					</li>
					
					<li><a href="#">about us</a></li>
					<li><a href="#">Rooms & Suites</a></li>
					
					<li class="parent"><a href="#.">Apartments</a>
				
			
					</li>
	<li class="parent"><a href="#.">Resources</a>
					<ul class="submenu">
                        <li> <a href="#">Gallery</a> </li>
							<li> <a href="#">FAQ</a> </li>
					</ul>
					
					</li>
					
					<li><a href="./contact">contact us</a>
					
				
					
					</li>
                </ul>	
            </nav>
            
				
			<ul class="get-touch">
				<li class="contact-no"><a><i class="icon-telephone-receiver"></i> <span>+2347077707117</span></a></li>
				<li class="book-table"><a href="https://reservations.oystershellhotels.com/rooms/"><span>book your room</span> <i class="icon-angle-right"></i></a></li>
				
				
				
			</ul>
	
	
       </header>

    
   <!--End Header-->
   
	
	
	
	
	<!-- Mobile Menu Start -->
	<div class="container">
    <div id="page">
			<header class="header">
				<a href="#menu"></a>
				
			</header>
			
			<nav id="menu">
				<ul>
					<li class="select"><a href="./">Home</a>
                    	
                    </li>
					
					<li><a href="#">About Us</a></li>
					<li><a href="#">Rooms & Suites</a></li>
					
					<li class="parent"><a href="#.">Apartments</a>
                    <li><a href="#.">Resources</a>
                    	<ul>
                        	<li> <a href="#">Gallery</a> </li>
							<li> <a href="#">FAQ</a> </li>
							
                        </ul>
                    </li>
					
					<li><a href="#.">Contact Us</a>
                    	
                    </li>

					</ul>
                
                
			</nav>
		</div>
		</div>
    <!-- Mobile Menu End -->