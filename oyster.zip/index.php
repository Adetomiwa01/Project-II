<?php 
include("./lib/oyster_header.php");
?>

	
	<!--Start Banner-->
   
   <div class="tp-banner-container">
   
   
	
		<div class="tp-banner" >
			<ul>
    	<!-- SLIDE  -->	
	
    
		<li data-transition="fade" data-slotamount="7" data-masterspeed="500"  data-saveperformance="on"  data-title="Intro Slide">
		
		<img src="https://res.cloudinary.com/dsz9ofw6a/image/upload/v1724211808/OysterSlide1_ocgevv.jpg"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">


		
		<div class="tp-caption arrowicon customin  rs-parallaxlevel-10"
			data-x="center"
			data-y="340" 
			data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			data-speed="850"
			data-start="1500"
			data-easing="Power3.easeInOut"
			data-elementdelay="0.1"
			data-endelementdelay="0.1"
			data-endspeed="1000"
			style=""><img src="imgs/slides/flower.png" alt="" >
		</div>
		
		
		<div class="tp-caption grey_heavy_72 customin tp-resizeme rs-parallaxlevel-10"
			data-x="center"
			data-y="416" 
			data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			data-speed="850"
			data-start="2500"
			data-easing="Power3.easeInOut"
			data-elementdelay="0.1"
			data-endelementdelay="0.1"	
			data-endspeed="1000"
			style="font-size:72px; z-index: 5; max-width: auto; max-height: auto; white-space: nowrap;">Welcome To
		</div>

		
		<div class="tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
			data-x="center"
			data-y="498" 
			data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			data-speed="500"
			data-start="3500"
			data-easing="Power3.easeInOut"
			data-splitin="none"
			data-splitout="none"
			data-elementdelay="0.05"
			data-endelementdelay="0.1"
			style="font-size:28px; z-index: 9; max-width: auto; max-height: auto; white-space: nowrap;"><div style="text-align:left;">Oyster Shell Hotel & Apartments</div>
		</div>
		
	</li>
	
	
	<li data-transition="fade" data-slotamount="7" data-masterspeed="500"  data-saveperformance="on"  data-title="Intro Slide">
		
		<img src="https://res.cloudinary.com/dsz9ofw6a/image/upload/v1724211808/OysterSlide1_ocgevv.jpg"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">


		
		<div class="tp-caption grey_heavy_72 customin tp-resizeme rs-parallaxlevel-10"
			data-x="0"
			data-y="396" 
			data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			data-speed="850"
			data-start="2500"
			data-easing="Power3.easeInOut"
			data-splitin="chars"
			data-splitout="none"
			data-elementdelay="0.1"
			data-endelementdelay="0.1"
			style="font-size:72px; z-index: 5; max-width: auto; max-height: auto; white-space: nowrap;">Welcome To
		</div>

		
		<div class="tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
			data-x="0"
			data-y="488" 
			data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			data-speed="500"
			data-start="3500"
			data-easing="Power3.easeInOut"
			data-splitin="chars"
			data-splitout="none"
			data-elementdelay="0.1"
			data-endelementdelay="0.1"
			style="font-size:28px; z-index: 9; max-width: auto; max-height: auto; white-space: nowrap;"><div style="text-align:left;">Oyster Shell Hotel & Apartments</div>
		</div>
		
		
	</li>
	
	
	<li data-transition="fade" data-slotamount="7" data-masterspeed="500"  data-saveperformance="on"  data-title="Intro Slide">
		
		<img src="https://res.cloudinary.com/dsz9ofw6a/image/upload/v1724211808/OysterSlide1_ocgevv.jpg"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">


		
		<div class="tp-caption arrowicon customin  rs-parallaxlevel-10"
			data-x="center"
			data-y="330" 
			data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			data-speed="850"
			data-start="1500"
			data-easing="Power3.easeInOut"
			data-elementdelay="0.1"
			data-endelementdelay="0.1"
			data-endspeed="1000"
			style=""><img src="imgs/slides/flower.png" alt="" >
		</div>
		
		
		<div class="tp-caption grey_heavy_72 customin tp-resizeme rs-parallaxlevel-10"
			data-x="center"
			data-y="406" 
			data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			data-speed="850"
			data-start="2500"
			data-easing="Power3.easeInOut"
			data-elementdelay="0.1"
			data-endelementdelay="0.1"	
			data-endspeed="1000"
			style="font-size:72px; z-index: 5; max-width: auto; max-height: auto; white-space: nowrap;">Welcome To
		</div>

		
		<div class="tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
			data-x="center"
			data-y="498" 
			data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			data-speed="500"
			data-start="3500"
			data-easing="Power3.easeInOut"
			data-splitin="none"
			data-splitout="none"
			data-elementdelay="0.05"
			data-endelementdelay="0.1"
			style="font-size:28px; z-index: 9; max-width: auto; max-height: auto; white-space: nowrap;"><div style="text-align:left;">Oyster Shell Hotel & Apartments</div>
		</div>
		
		
		<div class="tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
			data-x="center"
			data-y="580" 
			data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
			data-speed="800"
			data-start="4200"
			data-easing="Power3.easeInOut"
			data-splitin="none"
			data-splitout="none"
			data-elementdelay="0.05"
			data-endelementdelay="0.1"
			style="z-index: 9; max-width: auto; max-height: auto; white-space: nowrap;"><div style="text-align:left; ">
			<a href="#s" class="read-more" style=" line-height: initial; color: #fff; border:solid 2px #fff; text-transform: uppercase; font-weight: 500; letter-spacing: 0px; padding: 16px 36px; display: inline-block; font-size: 18px;">book now your room</a>
			</div>
		</div>
		
		
	</li>
	
	
	
    
</ul>
<div class="tp-bannertimer"></div>	</div>



<div class="container">
   <div class="booking-accor">
		<ul id="booking-accordion" class="booking-accordion">
			<li class="open">
				<div class="link"><img src="imgs/arrow-accordion.png" alt=""></div>
				
				<ul class="form-accordion" style="display:block;">
					<li>
					<div class="field">
					<input type="text" id="datepicker"  placeholder="Appointment Date" onClick="" name="datepicker" value="Choose A Date" onblur="if(this.value == '') { this.value='Choose A Date'}" onfocus="if (this.value == 'Choose A Date') {this.value=''}"/>		
					</div>
					
					<div class="field">
					<input type="text" id="datepicker2"  placeholder="Appointment Date" onClick="" name="datepicker" value="Choose A Date" onblur="if(this.value == '') { this.value='Choose A Date'}" onfocus="if (this.value == 'Choose A Date') {this.value=''}"/>		
					</div>
					
					<div class="field field2">
						<select class="basic-example" name="reserv_time">
							<option value="">Adults</option>
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
						</select>
					</div>
					
					<div class="field field2">
						<select class="basic-example" name="reserv_time">
							<option value="">Children</option>
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
						</select>
					</div>
					
					<a href="#s" class="availability">Check Availability</a>
					<li>
				</ul>
				
		</li>
		</ul>
	</div>
	</div>	
	

</div>	
   
   <!--End Banner-->
   
   
   
   <!--Start Content-->
   <div class="content">
       

       
       
		
		<!--Start Services-->
		<div class="services-two" style="padding-bottom:0px;">
			<div class="container">
				
				<div class="row">
				<div class="col-md-12">
					<div class="main-title">
					<h1>Rooms & Suites</h1>
					<p>Our rooms and suites offer a blend of luxury and comfort. Each space is thoughtfully designed with modern amenities, plush bedding, and elegant décor to provide a relaxing retreat.</p>
					</div>
				</div>
				</div>

				<div class="row">
                	
					<div class="serv-main-sec">
					
						<div class="col-md-4">
							<div class="service-sec">
								<img src="https://res.cloudinary.com/dsz9ofw6a/image/upload/v1723794931/superior_es2dwe.jpg" alt="">
								
								<div class="detail">
								<h6>Superior Room</h6>
								<p><b>₦25,000 / Night</b></p>
								<a href="#s">view detail</a>
								</div>
								
							</div>
						</div>
						
						<div class="col-md-4">
							<div class="service-sec">
								<img src="https://res.cloudinary.com/dsz9ofw6a/image/upload/v1723794875/classic_kwh7f5.jpg" alt="">
								
								<div class="detail">
								<h6>Classic Room</h6>
								<p><b>₦35,000 / Night</b></p>
								<a href="#">view detail</a>
								</div>
								
							</div>
						</div>
						
						<div class="col-md-4">
							<div class="service-sec">
								<img src="https://res.cloudinary.com/dsz9ofw6a/image/upload/v1723794799/deluxe_single_xa4r53.png" alt="">
								
								<div class="detail">
								<h6>Deluxe Single Room</h6>
								<p><b>₦45,000 / Night</b></p>
								<a href="#s">view detail</a>
								</div>
								
							</div>
						</div>
					
					</div>
					
					
				</div>	
				
				
				
				
					
								<div class="row">
                	
					<div class="serv-main-sec">
					
						<div class="col-md-6">
							<div class="service-sec">
								<img src="https://oystershellhotels.com/wp-content/uploads/2024/08/HS93dH.jpg" alt="">
								
								<!--<div class="detail">-->
								<!--<h6>Deluxe Room</h6>-->
								<!--<p>Lorem ipsum porta placerat rutrum aliquet platea accumsan, molestie eros aliquet adipiscing egestas ultrices.</p>-->
								<!--<a href="#s">view detail</a>-->
								<!--</div>-->
								
							</div>
						</div>
						
						<div class="col-md-6">
							<div class="service-sec">
								<!--<img src="imgs/our-services2.jpg" alt="">-->
								
								<div class="detail">
								<h6>Deluxe Premium Room</h6>
								<p><b>₦65,000 / Night</b></p>
								<a href="#">view detail</a>
								</div>
								
							</div>
						</div>
			
					
					</div>
					
					
				</div>
				
			
				

			</div>
		</div>
		<!--End Services-->
		
		

	
	
		<!--Start Rooms-->
			<div class="booking-steps" style="padding:0px;margin-bottom: 120px;">
				<div class="container">
				
					
	
					
					
					
					<!--Start Select Room-->
						
						<div class="detail-sections" style="margin:0px;">
							<div class="row">
					
							
							
							<div class="col-md-6">
								
								<div class="your-room">
								
									
									<div class="detail">
										<img src="https://res.cloudinary.com/dsz9ofw6a/image/upload/v1723794134/executive_usanou.jpg" alt="">
										
										<div class="text">
											<h6>Executive Suite</h6>
											<p>The Executive Suite at Oyster Shell Hotel offers a spacious and elegant retreat, perfect for both relaxation and business. With stylish furnishings, a comfortable living area, and modern amenities, it provides a serene environment for guests seeking luxury and privacy. Every detail is curated for comfort, making it ideal for a memorable stay.</p>
											<a href="#">BOOK NOW</a>
										</div>
										
										<div class="price-detail">
									
											<div class="stars">
												<i class="icon-star3"></i>
												<i class="icon-star3"></i>
												<i class="icon-star3"></i>
												<i class="icon-star3"></i>
												<i class="icon-star3"></i>
											</div>
											
											<div class="room-price">
												<span class="current">₦98,000 </span>
											
												<span class="per-night">*Per night</span>
											</div>
											
											
										</div>
										
									</div>
									
								</div>
								
							</div>
							
							
							
										<div class="col-md-6">
								
								<div class="your-room">
									
									
									<div class="detail">
										<img src="https://res.cloudinary.com/dsz9ofw6a/image/upload/v1723793953/Presidential_yeouta.jpg" alt="">
										
										<div class="text">
											<h6>Presidential Suite</h6>
											<p>The Presidential Suite exudes opulence and grandeur, offering the ultimate experience in luxury accommodation. It features expansive living spaces, premium furnishings, and exclusive amenities. This suite is designed to cater to distinguished guests seeking a refined and exclusive atmosphere, ensuring a stay of unmatched comfort.</p>
											<a href="#">BOOK NOW</a>
										</div>
										
										<div class="price-detail">
									
											<div class="stars">
												<i class="icon-star3"></i>
												<i class="icon-star3"></i>
												<i class="icon-star3"></i>
												<i class="icon-star3"></i>
												<i class="icon-star3"></i>
											</div>
											
											<div class="room-price">
												<span class="current">₦200,000</span>
											
												<span class="per-night">*Per night</span>
											</div>
											
											
										</div>
										
									</div>
									
								</div>
								
							</div>
							
							
							</div>
						</div>
						
						
					<!--End Select Room-->
					
					
					
					
					
					
					
				
				</div>
			</div>
		<!--End Rooms-->
		

	
		
		       		<!--Start Welcome Hotel-->
		<div class="welcome-hotel">
			
				<div class="parallax">
					<div class="container">
						
						<div class="welcome-detail">
							<div class="row">
							
							<div class="col-md-6">
								<div class="text">
									<h1>About Us</h1>
									<p>At Oyster Shell Hotel & Apartments, we provide an oasis of tranquility and elegance. Our stunning locations and breathtaking views create an unforgettable backdrop for your perfect getaway.</p>							
								</div>
							</div>
							
							
							<div class="col-md-6">
								<img class="welcome-img" src="https://res.cloudinary.com/dsz9ofw6a/image/upload/v1723698687/out-IMG_0804-HDR_tggd61.jpg" alt=""/>
							</div>
							
							</div>
						</div>
						
					</div>
					
				</div>
		
		</div>
		<!--End Welcome Hotel-->
		
		
		
   <!--Start Special Services-->
   <div class="special-services dark-bg">
   		<div class="container">
        	
            <div class="row">
	        <div class="col-md-12">
            
                <div class="main-title">
					<h1>Special services</h1>
					<p>Enjoy personalized concierge service, airport transfers, exclusive spa treatments, and tailored event planning. We cater to your unique needs, ensuring a seamless and luxurious experience during your stay.</p>
				</div>
            
            </div>
            </div>
            
           
           
           
            <div id="services">
        <div class="container">
          <div class="row">
            <div class="span12">

              <div id="special-services" class="owl-carousel">

                <div class="post item">
                    	<img class="lazyOwl" src="https://res.cloudinary.com/dsz9ofw6a/image/upload/v1724825832/IMG_0758-HDR__ljgaoc.jpg" alt="">
                        <div class="detail">
                        	<h4>Oyster Bar</h4>
							<p>Indulge in a tranquil oasis at our Oyster Bar, where elegance and Fun harmonize in a cozy yet refined ambiance. Savor expertly crafted cocktails, exotic wines, and premium whiskey, all carefully selected to provide a sophisticated escape from the ordinary. Whether you're seeking a relaxing retreat or a stylish spot to socialize, our Oyster Bar is the ultimate haven to unwind and rejuvenate after a long day.</p>
							<a href="#">view detail</a>
                        </div>
                </div>
               
			   
			    <div class="post item">
                    	<img class="lazyOwl" src="https://res.cloudinary.com/dsz9ofw6a/image/upload/v1723534588/4898718-1483260_0_0_4270_3202_1200_900_osdvqt.jpg" alt="">
                        <div class="detail">
                        	<h4>Oyster Spa</h4>
							<p>The Spa at Oyster Shell Hotel offers a serene escape with a range of rejuvenating treatments. Indulge in luxurious massages, skincare therapies, and wellness experiences, all designed to relax your body and revitalize your spirit. It's your oasis of tranquility in the heart of Lagos.</p>
							<a href="#">view detail</a>
                        </div>
                </div>
                
				

				
               

              </div>

            </div>
          </div>
        </div>

    </div>
    
    
            
        </div>
   </div>
   <!--End Special Services-->
   
   
  
   
   		<!--Start Oyster Tour-->
		<div class="about-hotel">
			<div class="container">
				
				
				
	
				        	
            <div class="row">
	        <div class="col-md-12">
            
                <div class="main-title">
					<h1>Amenities</h1>
					<p><b>Oyster Shell Hotel & Apartments</b> offers a range of premium amenities, featuring:
							<ul class="oyster_features_">
									<li><i><strong>- Swimming pool </strong></i></li>
									<li><i><strong>- Bar and lounge </strong></i></li>
										<li><i><strong>- 24-hour room service  </strong></i></li>
											<li><i><strong>- Private parking  </strong></i></li>
												<li><i><strong>- High-speed internet access  </strong></i></li>
													<li><i><strong>- Spa  </strong></i></li>
									
								</ul> Furthermore, our advanced <b>WATER TREATMENT SYSTEM</b> guarantees uncompromising hygiene standards. Our dedicated staff and modern facilities ensure a comfortable and relaxing stay.</p>
				</div>
            
            </div>
            </div>

				
		
				
				
				<div class="what-include">
					
					<div class="include-sec">
						<img src="imgs/icon-cup.png" alt="">
						<span>Breakfast</span>
					</div>
					
					<div class="include-sec">
						<img src="imgs/icon-ac.png" alt="">
						<span>Air Conditioning</span>
					</div>
					
					<div class="include-sec">
						<img src="imgs/icon-led.png" alt="">
						<span>TV LCD</span>
					</div>
					
					<div class="include-sec">
						<img src="imgs/icon-wifi.png" alt="">
						<span>Wi-fi service</span>
					</div>
					
					<div class="include-sec last">
						<img src="imgs/icon-car.png" alt="">
						<span>Free Parking</span>
					</div>
					
				</div>
				
				
				
			</div>
		</div>
		<!--End Oyster Tour-->
   
   
  
	
	<!--Start Customer Words-->
<!--
		<div class="customer-words">
			
				<div class="parallax parallax-customer-words">
					<div class="detail">
						
						<div class="main-title-white">
							<span>Some Words</span>
							<h1>FROM CUSTOMERS</h1>
						</div>
						
						<div id="testimonials">
							<div class="container">
								<div class="row">

									<div class="col-md-12">
									<div class="span12">

										<div id="owl-demo2" class="owl-carousel">

										<div class="testi-sec">
										<img src="https://res.cloudinary.com/dsz9ofw6a/image/upload/v1723752994/Nigerian_professional_resized_1_fvvfld.png" alt="">
										<div class="height35"></div>
										<span class="name">Emeka Adewale</span> 
										<span class="work">Business Executive</span>
										<div class="height20"></div>
										<p>Oyster Shell Hotel is a blend of elegance and comfort. As a business executive, I appreciate the sophisticated yet warm atmosphere. The Executive Suite offered me the perfect space to unwind after long meetings, and the service was impeccable.</p>
										<div class="height20"></div>
										<div class="rating">
											<i class="icon-star3"></i> <i class="icon-star3"></i> <i class="icon-star3"></i> <i class="icon-star3"></i> <i class="icon-star3"></i>
										</div>
										</div>
										
										<div class="testi-sec">
										<img src="https://res.cloudinary.com/dsz9ofw6a/image/upload/v1723752986/Nigerian_professional_resized_3_acauyk.png" alt="">
										<div class="height35"></div>
										<span class="name">Ngozi Amadi</span> 
										<span class="work">Wellness Expert</span>
										<div class="height20"></div>
										<p>The spa at Oyster Shell Hotel is a haven of peace. As a wellness expert, I was impressed by the variety of rejuvenating treatments they offer. I left feeling completely relaxed and recharged. Truly a luxurious experience in every way.</p>
										<div class="height20"></div>
										<div class="rating">
											<i class="icon-star3"></i> <i class="icon-star3"></i> <i class="icon-star3"></i> <i class="icon-star3"></i> <i class="icon-star3"></i>
										</div>
										</div>
										
										<div class="testi-sec">
										<img src="https://res.cloudinary.com/dsz9ofw6a/image/upload/v1723752991/Nigerian_professional_resized_2_tkjihk.png" alt="">
										<div class="height35"></div>
										<span class="name">Chidi Nwosu</span> 
										<span class="work">Tech Entrepreneur</span>
										<div class="height20"></div>
										<p>I found Oyster Shell Hotel to be a sanctuary in Lagos. Their innovative environment kept me inspired, especially the bar area, which was great for casual business discussions. The vibe was just what I needed for a perfect work and leisure balance.</p>
										<div class="height20"></div>
										<div class="rating">
											<i class="icon-star3"></i> <i class="icon-star3"></i> <i class="icon-star3"></i> <i class="icon-star3"></i> <i class="icon-star3"></i>
										</div>
										</div>


										</div>

									</div>
									</div>

								</div>
							</div>
						</div>
						
					</div>
				</div>
		
		</div>
		-->
		<!--End Customer Words-->
		
		
		
	 </div>
   <!--End Content-->
	
	
	
	
	
	
	
<?php 
include("./lib/oyster_footer.php");
?>


<!-- Date Picker -->	
<script type="text/javascript">
[].slice.call( document.querySelectorAll( 'input.input__field' ) ).forEach( function( inputEl ) {
// in case the input is already filled..

// events:
inputEl.addEventListener( 'focus', onInputFocus );
inputEl.addEventListener( 'blur', onInputBlur );
} );

function onInputFocus( ev ) {
classie.add( ev.target.parentNode, 'input--filled' );
}

function onInputBlur( ev ) {
if( ev.target.value.trim() === '' ) {
classie.remove( ev.target.parentNode, 'input--filled' );
}
}

//date picker
jQuery("#datepicker").datepicker({
inline: true
});

jQuery("#datepicker2").datepicker({
inline: true
});

<!-- Form Drop Down -->
$(document).ready(function() {

		$(".basic-example").heapbox();

});

</script>
 

<!-- Revolution Slider -->	
<script type="text/javascript">
jQuery('.tp-banner').show().revolution(
{
dottedOverlay:"none",
delay:16000,
startwidth:1170,
startheight:900,
hideThumbs:200,

thumbWidth:100,
thumbHeight:50,
thumbAmount:5,

navigationType:"nexttobullets",
navigationArrows:"solo",
navigationStyle:"preview",

touchenabled:"on",
onHoverStop:"on",

swipe_velocity: 0.7,
swipe_min_touches: 1,
swipe_max_touches: 1,
drag_block_vertical: false,

parallax:"mouse",
parallaxBgFreeze:"on",
parallaxLevels:[7,4,3,2,5,4,3,2,1,0],

keyboardNavigation:"off",

navigationHAlign:"center",
navigationVAlign:"bottom",
navigationHOffset:0,
navigationVOffset:20,

soloArrowLeftHalign:"left",
soloArrowLeftValign:"center",
soloArrowLeftHOffset:20,
soloArrowLeftVOffset:0,

soloArrowRightHalign:"right",
soloArrowRightValign:"center",
soloArrowRightHOffset:20,
soloArrowRightVOffset:0,

shadow:0,
fullWidth:"on",
fullScreen:"off",

spinner:"spinner4",

stopLoop:"off",
stopAfterLoops:-1,
stopAtSlide:-1,

shuffle:"off",

autoHeight:"off",						
forceFullWidth:"off",						



hideThumbsOnMobile:"off",
hideNavDelayOnMobile:1500,						
hideBulletsOnMobile:"off",
hideArrowsOnMobile:"off",
hideThumbsUnderResolution:0,

hideSliderAtLimit:0,
hideCaptionAtLimit:0,
hideAllCaptionAtLilmit:0,
startWithSlide:0,
videoJsPath:"rs-plugin/videojs/",
fullScreenOffsetContainer: ""	
});
</script>


</body>
</html>